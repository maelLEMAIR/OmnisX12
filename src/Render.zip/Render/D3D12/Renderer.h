﻿#ifndef RENDERER_H_INCLUDED
#define RENDERER_H_INCLUDED

#include <windows.h>
#include "Core/MathUtils.hpp"
#include "Core/Chrono.h"

#include "Device/GpuDevice.h"
#include "Device/CommandQueue.h"
#include "Device/FrameResource.h"
#include "Device/SwapChain.h"

#include "DirectX12/d3dx12.h"
#include "Items/RenderItem.h"

struct BoxDesc { XMFLOAT3 pos; XMFLOAT3 scale; float rotY; XMFLOAT4 color; };

static const BoxDesc kBoxDescs[] =
{
    { {-3.5f, 0.f, 0.f},  {1.f, 1.f,  1.f},  0.f,         {1.f,  0.2f, 0.2f, 1.f} },
    { { 0.f,  0.f, 0.f},  {1.f, 1.5f, 1.f},  XM_PIDIV4,   {0.2f, 1.f,  0.2f, 1.f} },
    { { 3.5f, 0.f, 0.f},  {1.f, 1.f,  1.f},  0.f,         {0.2f, 0.4f, 1.f,  1.f} },
};

static const int kNumBoxes = (int)std::size(kBoxDescs);

class Renderer
{
public:
    Renderer() = default;
    ~Renderer();

    void Init(HWND hwnd, int width, int height);
    void BuildBoxGeometry();
    void BuildFrameResources();
    void BuildRootSignature();
    void BuildShadersAndInputLayout();
    void OnResize(int width, int height);
    void Update(Chrono const& chrono);
    void UpdateObjectCBs(Chrono const& chrono);
    void UpdateMainPassCB(Chrono const& chrono);
    void Draw();

    bool Get4xMsaaState()const { return m_4xMsaaState; }
    void Set4xMsaaState(bool value);
    
    void AddRenderItem(RenderItem& renderItem) { renderItem.NumFramesDirty = NumFrameResources ;mAllRItems.push_back(renderItem); }
private:
    D3D12_CPU_DESCRIPTOR_HANDLE DepthStencilView() const;

private:
    void BeginDraw();
    void DrawScene();
    void EndDraw();
    void BuildDescriptorHeaps();
    void BuildConstantBuffers();
    void BuildRenderObjects();
    void BuildPSO();

    ComPtr<ID3D12RootSignature>  m_rootSignature = nullptr;
    ComPtr<ID3D12DescriptorHeap> m_cbvHeap       = nullptr;
    
    ComPtr<ID3DBlob> m_vsByteCode = nullptr;
    ComPtr<ID3DBlob> m_psByteCode = nullptr;

    GpuDevice    m_device;
    CommandQueue m_commandQueue;
    SwapChain    m_swapChain;

    std::unique_ptr<UploadBuffer<ObjectConstants>> m_objectCB;
    std::unique_ptr<MeshGeometry>                  m_boxGeo;
    
    static const int NumFrameResources = 1;
    std::vector<std::unique_ptr<FrameResource>> mFrameResources;
    FrameResource* mCurrFrameResource = nullptr;
    int mCurrFrameResourceIndex = 0;
    
    HWND m_hwnd = nullptr;
    PassConstants mMainPassCB;
    XMFLOAT3 mEyePos = XMFLOAT3(0.0f, 0.0f, 0.0f);
    
    bool      m_4xMsaaState = false;
    UINT      m_4xMsaaQuality = 0;
    
    std::vector<D3D12_INPUT_ELEMENT_DESC> mInputLayout;
    std::unordered_map<std::string, ComPtr<ID3D12PipelineState>> mPSOs;
    
    std::vector<RenderItem> mAllRItems;
    
    ComPtr<ID3D12DescriptorHeap> m_dsvHeap;
    ComPtr<ID3D12Resource>       m_depthStencilBuffer;
    DXGI_FORMAT m_depthStencilFormat = DXGI_FORMAT_D24_UNORM_S8_UINT;

    UINT m_rRtvDescriptorSize = 0;
    UINT m_dsvDescriptorSize = 0;
    UINT m_cbvSrvUavDescriptorSize = 0;
    
    D3D12_VIEWPORT m_screenViewport = {};
    D3D12_RECT     m_scissorRect = {};
    int m_clientWidth  = 800;
    int m_clientHeight = 600;

    DirectX::XMFLOAT4X4 mWorld = MathUtils::Identity4x4();
    DirectX::XMFLOAT4X4 mView  = MathUtils::Identity4x4();
    DirectX::XMFLOAT4X4 mProj  = MathUtils::Identity4x4();

    // TODO (à rapatrier depuis WindowD3D12) : m_cbvHeap, m_objectCB, m_rootSignature,
    // mvsByteCode, mpsByteCode, mInputLayout, mBoxGeo, mPSOs
};

#endif
