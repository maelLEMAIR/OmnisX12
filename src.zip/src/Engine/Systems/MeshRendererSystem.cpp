﻿#ifndef MESH_RENDERER_SYSTEM_CPP_INCLUDED
#define MESH_RENDERER_SYSTEM_CPP_INCLUDED

#include "MeshRendererSystem.h"

#include "EngineManager.h"
#include "ResourceManager.h"
#include "../Components/MeshRenderer.hpp"
#include "../Components/TransformComponent.hpp"
#include "ECS/World.h"

void MeshRendererSystem::Update(World& world, float deltaTime)
{
    Renderer* pRenderer = EngineManager::GetRenderer();
    world.Query<MeshRenderer, TransformComponent>([&](MeshRenderer& _mesh, TransformComponent& _transform)
    {   
        Geometry* geo = ResourceManager::GetGeometry(_mesh.geoId);
        
        if (geo == nullptr) return;

        MeshGeometry* meshGeo = pRenderer->CreateGeometry(geo->vertices, geo->indices);
        pRenderer->Draw(*meshGeo, _transform.world.GetMatrix());
    });
}

#endif